# Masterani.me watch addon

## Installation
As this is plain Javascript it does not require any specific tools to build

## Firefox min version
It does require firefox V3.5 as I am using window.localStorage api.

## Other
Right now I use the example icon as I have nothing better yet, however I am looking into improving this.

## License
All the code is written by myself, and I am planning to release the source code on github later on (in the comming days)